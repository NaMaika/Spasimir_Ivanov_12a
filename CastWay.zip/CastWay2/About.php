<?php
@include 'config.php';
session_start();
$users_id = $_SESSION['id'] ?? null;;
$is_logged_in = isset($users_id);




// Search handling with partial matches
if(isset($_GET['search'])) {
    $search_query = strtolower(trim($_GET['search'])); // Convert to lowercase and trim whitespace

    if(strpos($search_query, 'сиг') === 0) {
        header('Location: signalers.php');
    } else if(strpos($search_query, 'мак') === 0) {
        header('Location: reel.php');
    } else if(strpos($search_query, 'въд') === 0) {
        header('Location: fishing-rod.php');
    } else if(strpos($search_query, 'обо') === 0) {
        header('Location: equipment.php');
    } else if(strpos($search_query, 'зах') === 0) {
        header('Location: fishing-supplies.php');
    } else {
        $message[] = 'Product not found';
    }
    exit;
}
if (isset($_GET['logout'])) {
    // Destroy the session
    session_unset(); // Remove all session variables
    session_destroy(); // Destroy the session itself
    header("Location: CastWayMain.php"); // Redirect to the login page
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CastWay</title>
    <link rel="stylesheet" href="css/CastWayMain.css"> 
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/about.css">
</head>
<body>
<div class="header">
        <?php if ($is_logged_in): ?>
        <a href="MainPage.php" class="logo">
            <img src="img/CastWay.jpg" alt="Company Logo">
        </a>
        <?php else: ?>
            <a href="CastWayMain.php" class="logo">
                <img src="img/CastWay.jpg" alt="Company Logo">
            </a>
            <?php endif; ?>

    <div class="header-center">
        <form action="" method="get" class="search-form">
            <input type="text" name="search" placeholder="Търси продукти..." list="product-list" required oninput="checkInput(this.value)">
            <datalist id="product-list">
                <!-- Options will be dynamically filled by JavaScript -->
            </datalist>
            <button type="submit">Search</button>
        </form>
    </div>

    <div class="header-right">
        <?php if ($is_logged_in): ?>
            <?php
            $select_rows = mysqli_query($conn, "SELECT * FROM `cart` where users_id = '$users_id'") or die('query failed');
            $row_count = mysqli_num_rows($select_rows);
            ?>
            <a href="cart.php" class="cart">Количка <span><?php echo $row_count; ?></span></a> 
            <a href="?logout">Изход</a>
        <?php else: ?>
            <a href="Register.php" class="login">Вход</a>
        <?php endif; ?>
        
       
    </div>
</div>
    <div class="container">
        <h1>За нас</h1>
        <p>Когато става дума за риболов, правилните принадлежности и оборудване са от съществено значение за успешен ден на водата. В нашия магазин за рибарски принадлежности ние предлагаме широк асортимент от продукти, които задоволяват нуждите на както начинаещи, така и опитни риболовци. От въдици и макари до сигнализатори и най-различни видове стръв, нашата цел е да предоставим на нашите клиенти всичко необходимо за тяхното риболовно приключение под един покрив.</p>
        <p>Разбираме, че риболовът е повече от хоби; той е страст, която свързва хората с природата. Ето защо се стремим да предлагаме само най-висококачествените продукти, които са тествани и одобрени от опитни риболовци. Нашите служители са компетентни и винаги готови да помогнат със съвети и препоръки, базирани на личен опит и знания.</p>
        <p>Независимо дали сте в търсене на обновяване на своя риболовен арсенал или тепърва започвате с риболова, при нас ще намерите уютна и приятелска атмосфера, където всеки въпрос или нужда ще бъде адресирана с професионализъм. Добре дошли в света на риболова, където приключението започва с правилния избор на оборудване!</p>
    </div>
</body>
</html>
