function addToCart(event, isLoggedIn) {
    if (!isLoggedIn) {
        event.preventDefault(); // Stop the form from submitting
        const messageContainer = document.getElementById('message-container');
        messageContainer.innerHTML = '<div class="message">Please register or log in to add items to your cart.</div>';
        messageContainer.style.display = 'block'; // Show the message
        setTimeout(function() {
            messageContainer.style.display = 'none'; // Hide the message after 3 seconds
        }, 3000);
    }
}