let currentIndex = 0;
const items = document.querySelectorAll('.carousel-item');
const totalItems = items.length;

function switchItem() {
    const carouselInner = document.querySelector('.carousel-inner');
    const width = items[0].clientWidth;
    currentIndex = (currentIndex + 1) % totalItems;
    carouselInner.style.transform = `translateX(-${currentIndex * width}px)`;
}

setInterval(switchItem, 3000); // Change every 5 seconds