document.querySelector('.search-form input[name="search"]').addEventListener('input', function(e) {
    var inputVal = e.target.value.toLowerCase();
    var dataList = document.getElementById('product-list');
    dataList.innerHTML = ''; // Clear existing options

    if (inputVal.length >= 3) { // Check if at least three letters are typed
        // Define your page mappings based on keywords
        const pageMappings = {
            'сиг': {displayName: 'сигнализатори', url: 'signalers.php'},
            'мак': {displayName: 'макари', url: 'reel.php'},
            'въд': {displayName: 'въдици', url: 'fishing-rod.php'},
            'обо': {displayName: 'оборудване', url: 'equipment.php'},
            'зах': {displayName: 'захранки', url: 'fishing-supplies.php'}
        };

        // Loop through mappings and add options based on matching the input
        Object.keys(pageMappings).forEach(key => {
            if (key.startsWith(inputVal)) {
                var option = document.createElement('option');
                option.value = pageMappings[key].displayName; // Use the full name for display
                option.textContent = pageMappings[key].displayName; // Option text is the full name
                dataList.appendChild(option);
            }
        });
    }
});

// Redirect on selection of an option
document.querySelector('.search-form input[name="search"]').addEventListener('change', function(e) {
    var displayName = e.target.value;
    // Reverse lookup to find the URL based on the selected display name
    const displayNameToURL = {
        'сигнализатори': 'signalers.php',
        'макари': 'reel.php',
        'въдици': 'fishing-rod.php',
        'оборудване': 'equipment.php',
        'захранки': 'fishing-supplies.php'
    };

    var page = displayNameToURL[displayName];
    if (page) { // If a page is found, redirect to it
        window.location.href = page;
    }
});

