
<?php
session_start();

$servername = "localhost";
 $username = 'root';
 $password = "";
 $dbname = "CastWay";

 $conn = new mysqli($servername, $username, $password, $dbname);
 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
 }

// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once "config.php"; // Assuming database details are in config.php

    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $username = trim($_POST["username"]); // Make sure 'username' matches the input name in your form
    $password = $_POST["password"];

    if (empty($username)) {
        $username_err = "Please enter username.";
    }
    if (empty($password)) {
        $password_err = "Please enter your password.";
    }

    if (empty($username_err) && empty($password_err)) {
        $sql = "SELECT id, username, password FROM adminlog WHERE username = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $username);
            if ($stmt->execute()) {
                $stmt->store_result();
                if ($stmt->num_rows == 1) {
                    $stmt->bind_result($id, $username, $hashed_password);
                    if ($stmt->fetch()) {
                        // Debugging: Output fetched password hash
                        error_log("Fetched hashed password from DB: " . $hashed_password);
                        error_log("Submitted password that will be verified: " . $password);
                    
                        if (password_verify($hashed_password,$password )) {
                            // Password is correct
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;
                            header("location: admin.php");
                            exit; // Don't forget to call exit after header redirection
                        } else {
                            $login_err = "Invalid password.";
                        }
                    }
                } else {
                    $login_err = "Invalid username.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            $stmt->close();
        }
    }
    $conn->close();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>CastWay</title>
    <link rel="stylesheet" type="text/css" href="css/Login.css"> 
    <style>

        
    </style>
</head>
<body>
    <div class="login-box">
        <h2>Admin Login</h2>

        <?php 
        if (!empty($login_err)) {
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }         
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

            <div class="form-group">
                <label>Username/Email</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Login">
            </div>
            <p>Don't have an account? <a href="SignIn.php">Sign up </a> now.</p>
            <p>Enter as admin <a href="admin_register.php"> Here </a></p>
        </form>
    </div>    
</body>
</html> 