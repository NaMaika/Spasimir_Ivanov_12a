<?php
session_start();
@include 'config.php';
$users_id = $_SESSION['id'];

if(isset($_POST['order_btn'])){

   $name = $_POST['name'];
   $number = $_POST['number'];
   $email = $_POST['email'];
   $method = $_POST['method'];
   $flat = $_POST['flat'];
   $street = $_POST['street'];
   $city = $_POST['city'];
   $state = $_POST['state'];
   $country = $_POST['country'];
   $pin_code = $_POST['pin_code'];

   $cart_query = mysqli_query($conn, "SELECT * FROM `cart` WHERE users_id = '$users_id'");
   $price_total = 0;
   if(mysqli_num_rows($cart_query) > 0){
      while($product_item = mysqli_fetch_assoc($cart_query)){
         $product_name[] = $product_item['name'] .' ('. $product_item['quantity'] .') ';
         $product_price = number_format($product_item['price'] * $product_item['quantity']);
         $price_total += $product_price;
      }
      $discounted_total = $price_total - ($price_total * 0.20);; 
   }

   $total_product = implode(', ',$product_name);
   $detail_query = mysqli_query($conn, "INSERT INTO `order` (name, number, email, method, flat, street, city, state, country, pin_code, total_products, total_price) VALUES ('$name', '$number', '$email', '$method', '$flat', '$street', '$city', '$state', '$country', '$pin_code', '$total_product', '$discounted_total')") or die('query failed');

   if($cart_query && $detail_query){
      echo "
      <div class='order-message-container'>
      <div class='message-container'>
         <h3>Благодарим за поръчката</h3>
         <div class='order-detail'>
            <span>".$total_product."</span>
            <span class='total'> Сума : ".$discounted_total."лв  </span>
         </div>
         <div class='customer-details'>
            <p> Име : <span>".$name."</span> </p>
            <p> Телефон : <span>".$number."</span> </p>
            <p> Имейл : <span>".$email."</span> </p>
            <p> Адрес : <span>".$flat.", ".$street.", ".$city.", ".$state.", ".$country." - ".$pin_code."</span> </p>
            <p> Плащане : <span>".$method."</span> </p>
            <p>(*Плащане само на място*)</p>
         </div>
            <a href='MainPage.php' class='btn'>Продължи пазаруването</a>
         </div>
      </div>
      ";
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Checkout</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
<section class="checkout-form">
   <h1 class="heading">complete your order</h1>
   <form action="" method="post">
   <div class="display-order">
      <?php
         $select_cart = mysqli_query($conn, "SELECT * FROM `cart` WHERE users_id = '$users_id'");
         $total = 0;
         $grand_total = 0;
         if(mysqli_num_rows($select_cart) > 0){
            while($fetch_cart = mysqli_fetch_assoc($select_cart)){
               $total_price = number_format($fetch_cart['price'] * $fetch_cart['quantity']);
               $total += $total_price;
               $grand_total = $total - ($total * 0.20); // Apply 20% discount
               echo "<span>".$fetch_cart['name']." (".$fetch_cart['quantity'].")</span><br>"; // Display each item within the loop
            $items_displayed = true;
            }
            echo "<span class='grand-total'> Крайна цена : ".$grand_total."лв </span>";
         } else {
            echo "<div class='display-order'><span>your cart is empty!</span></div>";
         }
         if (!$items_displayed) { // Handle case where no items are displayed
            echo "<div class='display-order'><span>No items to display.</span></div>";
        }
      ?>
       
      
     
   </div>

      <div class="flex">
         <div class="inputBox">
            <span>Име</span>
            <input type="text" placeholder="Въведете име" name="name" required>
         </div>
         <div class="inputBox">
            <span>Телефон</span>
            <input type="number" placeholder="Въведете телефон" name="number" required>
         </div>
         <div class="inputBox">
            <span>Имейл</span>
            <input type="email" placeholder="Въведете имейл" name="email" required>
         </div>
         <div class="inputBox">
            <span>Метод на плащане</span>
            <select name="method">
               <option value="cash on delivery" selected>Наложен платеж</option>
               <option value="credit cart">Дебитна/Кредитна карта</option>
               
            </select>
         </div>
         <div class="inputBox">
            <span>Адрес</span>
            <input type="text" placeholder="Адрес" name="flat" required>
         </div>
         <div class="inputBox">
            <span>Улица</span>
            <input type="text" placeholder="Улеца" name="street" required>
         </div>
         <div class="inputBox">
            <span>Град/Село</span>
            <input type="text" placeholder="Град/Село" name="city" required>
         </div>
         <div class="inputBox">
            <span>Област</span>
            <input type="text" placeholder="Област" name="state" required>
         </div>
         <div class="inputBox">
            <span>Държава</span>
            <input type="text" placeholder="Държава" name="country" required>
         </div>
         <div class="inputBox">
            <span>Пощенски код</span>
            <input type="text" placeholder="Пощенски код" name="pin_code" required>
         </div>
      </div>
      <input type="submit" value="Поръчай" name="order_btn" class="btn">
   </form>

</section>

</div>

<!-- custom js file link  -->
<script src="js/script.js"></script>
   
</body>
</html>