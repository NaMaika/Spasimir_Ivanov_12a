<?php
$conn = mysqli_connect('localhost','root','','castway') 
or die('connection failed');
?>