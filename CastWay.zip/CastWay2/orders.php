<?php
@include 'config.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL to delete a record
if(isset($_GET['delete_id'])){
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM `order` WHERE id = ?"; // Assuming the primary key is `id`
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $delete_id);
    if($stmt->execute()){
        header('location:orders.php');
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }
    $stmt->close();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Поръчки</title>
    <link rel="stylesheet" href="css/users.css">
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #dddddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .button-danger { color: white; background-color: red; border: none; padding: 5px 10px; }
    </style>
</head>
<body>
<div class="header">
        <div class="dropdown">
            <button class="dropbtn">Продукти</button>         
            <div class="dropdown-content">
                <a href="add-rods.php">Въдици</a>
                <a href="add-reel.php">Макари</a>
                <a href="add-signalers.php">Сигнализатори</a>
                <a href="add-supplies.php">Захранки</a>
                <a href="add-equipment.php">Оборудване</a>
                <a href="admin.php">Последни продукти</a>
            </div>
        </div>
        <div class="dropdown">
            <button class="dropbtn">Потребители</button>
            <div class="dropdown-content">
            <a href="users.php">Потребители</a>
            <a href="orders.php">Поръчки</a>
            </div>

        </div>
    </div>
    <h1>Поръчки</h1>
    <table>
        <thead>
            <tr>
                <th>Име</th>
                <th>Номер</th>
                <th>Имейл</th>
                <th>Плащане</th>
                <th>Адрес</th>
                <th>Продукти</th>
                <th>Цена</th>
                <th>Изтрий</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT id, name, number, email, method, flat, street, city, state, country, pin_code, total_products, total_price FROM `order`";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$row['name']}</td>
                        <td>{$row['number']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['method']}</td>
                        <td>{$row['flat']}, {$row['street']}, {$row['city']}, {$row['state']}, {$row['country']}, {$row['pin_code']}</td>
                        <td>{$row['total_products']}</td>
                        <td>{$row['total_price']}</td>
                        <td><button onclick='confirmDelete({$row['id']})' class='button-danger'>Изтрий</button></td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No orders found</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>
</body>
</html>
<script>
function confirmDelete(id) {
    if (confirm("Are you sure you want to delete this order?")) {
        window.location.href = "orders.php?delete_id=" + id;
    }
}
</script>
