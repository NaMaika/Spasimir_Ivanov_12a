<?php
@include 'config.php';
session_start();
$users_id = $_SESSION['id'] ?? null;;
$is_logged_in = isset($users_id);
if(isset($_POST['add_to_cart'])){

   
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_POST['product_image'];
    $product_quantity = 1;
 
    $select_cart = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' and users_id = '$users_id'");
 
    if(mysqli_num_rows($select_cart) > 0){
      
   }else{
      $insert_product = mysqli_query($conn, "INSERT INTO `cart`(users_id,name, price, image, quantity) VALUES('$users_id','$product_name', '$product_price', '$product_image', '$product_quantity')");
      
   }
 
 } 

 // Search handling with partial matches
 if(isset($_GET['search'])) {
   $search_query = strtolower(trim($_GET['search'])); // Convert to lowercase and trim whitespace

   if(strpos($search_query, 'сиг') === 0) {
       header('Location: signalers.php');
   } else if(strpos($search_query, 'мак') === 0) {
       header('Location: reel.php');
   } else if(strpos($search_query, 'въд') === 0) {
       header('Location: fishing-rod.php');
   } else if(strpos($search_query, 'обо') === 0) {
       header('Location: equipment.php');
   } else if(strpos($search_query, 'зах') === 0) {
       header('Location: fishing-supplies.php');
   } else {
       $message[] = 'Product not found';
   }
   exit;
}

if (isset($_GET['logout'])) {
    // Destroy the session
    session_unset(); // Remove all session variables
    session_destroy(); // Destroy the session itself
    header("Location: CastWayMain.php"); // Redirect to the login page
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/CastWayMain.css"> 
    <link rel="stylesheet" href="css/style.css">
    <title>CastWay</title>
    <script src="JavaScript/searchbar.js"></script>
    <script>
        function addToCart(event, isLoggedIn) {
            if (!isLoggedIn) {
                event.preventDefault(); // Stop the form from submitting
                alert('Please log in first to add items to your cart.');
            }
        }
    </script>
</head>
<body>
<div class="header">
        <?php if ($is_logged_in): ?>
        <a href="MainPage.php" class="logo">
            <img src="img/CastWay.jpg" alt="Company Logo">
        </a>
        <?php else: ?>
            <a href="CastWayMain.php" class="logo">
                <img src="img/CastWay.jpg" alt="Company Logo">
            </a>
            <?php endif; ?>

    <div class="header-center">
        <form action="" method="get" class="search-form">
            <input type="text" name="search" placeholder="Търси продукти..." list="product-list" required oninput="checkInput(this.value)">
            <datalist id="product-list">
                <!-- Options will be dynamically filled by JavaScript -->
            </datalist>
            <button type="submit">Search</button>
        </form>
    </div>

    <div class="header-right">
        <?php if ($is_logged_in): ?>
            <?php
            $select_rows = mysqli_query($conn, "SELECT * FROM `cart` where users_id = '$users_id'") or die('query failed');
            $row_count = mysqli_num_rows($select_rows);
            ?>
            <a href="cart.php" class="cart">Количка <span><?php echo $row_count; ?></span></a> 
            <a href="?logout">Изход</a>
        <?php else: ?>
            <a href="Register.php" class="login">Вход</a>
        <?php endif; ?>
        <a href="#about">За нас</a>
       
    </div>
</div>
<div id="message-container" style="display: none; color: red; position: absolute; top: 20px; right: 20px; z-index: 1000;"></div>
<br>
<br>
    <?php

if(isset($message)){
   foreach($message as $message){
      echo '<div class="message"><span>'.$message.'</span> <i class="fas fa-times" onclick="this.parentElement.style.display = `none`;"></i> </div>';
   };
};

?>



<div class="container">

<section class="products">


   <div class="box-container">

      <?php
      
      $select_products = mysqli_query($conn, "SELECT * FROM `reels`");
      if(mysqli_num_rows($select_products) > 0){
         while($fetch_product = mysqli_fetch_assoc($select_products)){
      ?>

        <form action="" method="post" onsubmit="addToCart(event, <?php echo $is_logged_in ? 'true' : 'false'; ?>)">
            <div class="box">
                <img src="uploaded_img/<?php echo $fetch_product['image']; ?>" alt="">
                <h3><?php echo $fetch_product['name']; ?></h3>
                <div class="price"><?php echo $fetch_product['price']; ?>лв</div>
                <input type="hidden" name="product_name" value="<?php echo $fetch_product['name']; ?>">
                <input type="hidden" name="product_price" value="<?php echo $fetch_product['price']; ?>">
                <input type="hidden" name="product_image" value="<?php echo $fetch_product['image']; ?>">
                <input type="submit" class="btn" value="Add to cart" name="add_to_cart">
            </div>
        </form>

      <?php
         };
      };
      ?>

   </div>

</section>

</div>
</body>
<footer class="footer">
        <div class="footer-content">
            <div class="footer-section about">
                <h3>CastWay</h3>
                <p>CastWay е твой доверен партньор при покупка на рибарски принадлежности. Ние предлагаме високо качествени продукти, които ще направят риболова незабравим.</p>
                <div class="contact">
                    <span><i class="fas fa-phone"></i> &nbsp; 123-456-789</span>
                    <span><i class="fas fa-envelope"></i> &nbsp; info@castway.com</span>
                </div>
                <div class="socials">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
            <div class="footer-section links">
                <h3>Бърси връзки</h3>
                <ul>
                    <li><a href="CastWayMain.php">Home</a></li>
                    <li><a href="About.php">За нас</a></li>
                    <li><a href="Register.php">Вход/Регистрация</a></li>
                </ul>
            </div>
            <div class="footer-section newsletter">
                <h3>Имейл</h3>
                <p>Получавай известия за нови продукти</p>
                <form action="" method="post">
                    <input type="email" name="email" placeholder="Your email address">
                    <button type="submit">Абонирай се</button>
                </form>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; castway.com | Designed by Спасимир Иванов
        </div>
    </footer>
</html>



<style>
    .footer {
    background-color: #2c3e50;
    color: #d1d8e0;
    text-align: left;
    padding: 20px 0;
}

.footer-content {
    display: flex;
    justify-content: space-between;
    padding: 0 50px;
}

.footer-section {
    flex: 1;
    padding: 20px;
}

.footer-section h3 {
    color: #fff;
}

.footer-section p, .footer-section span {
    color: #bcccdc;
    font-size: 14px;
    margin-bottom: 10px;
}

.footer-section a {
    color: #bcccdc;
    text-decoration: none;
}

.socials a {
    margin: 0 10px;
    color: #fff;
    font-size: 24px;
}

.footer-bottom {
    background-color: #34495e;
    color: #686f7a;
    text-align: center;
    padding: 10px;
    font-size: 14px;
}

.newsletter form {
    display: flex;
}

.newsletter input[type="email"], .newsletter button {
    padding: 10px;
    margin-top: 5px;
}

.newsletter button {
    background-color: #e74c3c;
    border: none;
    color: white;
    cursor: pointer;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .footer-content {
        flex-direction: column;
    }

    .footer-section {
        margin-bottom: 20px;
    }
}
    .header a.logo img {
    height: 50px;  /* Adjust the height to fit the header */
    width: 50px;   /* Maintain the aspect ratio */
    display: block; /* Removes bottom space/gap under the image */
}
.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    background-color:#2980b9;
}

.header a.logo {
    font-size: 24px;
    color: #333;
    text-decoration: none;
}

.header-center {
    flex-grow: 1;
    display: flex;
    justify-content: center;
}

.search-form {
    position: relative;
    width: 300px;
}

.search-form input[type="text"] {
    width: 100%;
    padding: 10px;
    border: 2px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    color: #333;
}

.search-form button {
    position: absolute;
    right: 0;
    top: 0;
    bottom: 0;
    background-color: #007BFF;
    color: white;
    border: none;
    border-radius: 0 5px 5px 0;
    padding: 0 15px;
    font-size: 16px;
    cursor: pointer;
}

.header-right {
    display: flex;
    align-items: center;
}

.header-right a {
    text-decoration: none;
    color: #333;
    margin-left: 20px;
    font-size: 20px;
}


</style>